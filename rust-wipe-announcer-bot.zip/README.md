# Rust Wipe Announcer Discord Bot

Бот берет ближайшие вайпы Rust-серверов из BattleMetrics и отправляет новые объявления в Discord-канал.

## Установка

1. Установи зависимости:

```powershell
npm install
```

2. Скопируй конфиг:

```powershell
Copy-Item .env.example .env
```

3. Заполни `.env`:

- `DISCORD_TOKEN` - токен бота из Discord Developer Portal.
- `DISCORD_CHANNEL_ID` - ID канала для объявлений.
- `WIPE_SOURCE_URL` - ссылка на список BattleMetrics. По умолчанию уже стоит нужная:
  `https://www.battlemetrics.com/servers/rust?sort=details.rust_next_wipe`
- `BATTLEMETRICS_PAGE_SIZE` - сколько серверов проверять из начала списка.
- `BATTLEMETRICS_FETCH_PAGES` - сколько страниц API можно просмотреть, чтобы найти нужный тип серверов.
- `SERVER_TYPE=official` - фильтр как галочка `TYPE -> official` на BattleMetrics.
- `ANNOUNCE_WITHIN_MINUTES` - за сколько минут до вайпа отправлять объявление. Пустое значение отключает ограничение.
- `MIN_PLAYERS`, `MAX_PLAYERS`, `COUNTRIES` - дополнительные фильтры, можно оставить пустыми.

4. Запусти:

```powershell
npm start
```

Для одноразовой проверки без постоянного цикла:

```powershell
npm run check
```

## Как получить ID канала

В Discord включи `User Settings -> Advanced -> Developer Mode`, затем ПКМ по каналу и `Copy Channel ID`.

## Как пригласить бота

В Discord Developer Portal открой приложение бота, затем `OAuth2 -> URL Generator`.

Выбери:

- `bot`
- `Send Messages`
- `Embed Links`
- `View Channel`

Открой сгенерированную ссылку и добавь бота на сервер.

## Как это работает

Бот использует публичный API BattleMetrics:

```text
https://api.battlemetrics.com/servers?filter[game]=rust&sort=details.rust_next_wipe
```

Чтобы не отправлять одно и то же объявление повторно, бот сохраняет уже отправленные пары `serverId + nextWipe` в `data/seen-wipes.json`.
