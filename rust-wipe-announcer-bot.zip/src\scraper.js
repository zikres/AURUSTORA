const battleMetricsApiUrl = 'https://api.battlemetrics.com/servers';

function formatDate(value, timezone) {
  if (!value) {
    return '';
  }

  return new Intl.DateTimeFormat('ru-RU', {
    dateStyle: 'medium',
    timeStyle: 'short',
    timeZone: timezone
  }).format(new Date(value));
}

function buildApiUrl(config) {
  const url = new URL(battleMetricsApiUrl);
  url.searchParams.set('filter[game]', 'rust');
  url.searchParams.set('sort', 'details.rust_next_wipe');
  url.searchParams.set('page[size]', '100');

  if (config.battleMetrics.minPlayers !== null) {
    url.searchParams.set('filter[players][min]', String(config.battleMetrics.minPlayers));
  }

  if (config.battleMetrics.maxPlayers !== null) {
    url.searchParams.set('filter[players][max]', String(config.battleMetrics.maxPlayers));
  }

  if (config.battleMetrics.countries) {
    url.searchParams.set('filter[countries]', config.battleMetrics.countries);
  }

  return url;
}

async function fetchBattleMetricsPage(url) {
  const response = await fetch(url, {
    headers: {
      accept: 'application/json',
      'user-agent': 'RustWipeAnnouncerBot/1.0'
    }
  });

  if (!response.ok) {
    throw new Error(`BattleMetrics returned ${response.status} ${response.statusText}`);
  }

  return response.json();
}

function isWithinAnnouncementWindow(nextWipe, config) {
  const minutes = config.battleMetrics.announceWithinMinutes;

  if (minutes === null) {
    return true;
  }

  const wipeAt = new Date(nextWipe).getTime();
  const now = Date.now();
  const max = now + minutes * 60 * 1000;

  return wipeAt >= now && wipeAt <= max;
}

function matchesServerType(server, config) {
  const expected = config.battleMetrics.serverType;

  if (!expected) {
    return true;
  }

  const details = server.attributes?.details ?? {};
  const rustType = details.rust_type?.toLowerCase();

  if (expected === 'official') {
    return rustType === 'official' && details.official === true;
  }

  if (expected === 'modded') {
    return rustType === 'modded';
  }

  return rustType === expected;
}

function toWipe(server, config) {
  const attributes = server.attributes;
  const details = attributes.details ?? {};
  const nextWipe = details.rust_next_wipe;
  const lastWipe = details.rust_last_wipe;
  const serverUrl = `https://www.battlemetrics.com/servers/rust/${server.id}`;

  return {
    id: `${server.id}:${nextWipe}`,
    title: attributes.name,
    timestamp: nextWipe,
    date: formatDate(nextWipe, config.timezone),
    link: serverUrl,
    serverId: server.id,
    players: `${attributes.players}/${attributes.maxPlayers}`,
    address: attributes.ip && attributes.port ? `${attributes.ip}:${attributes.port}` : '',
    country: attributes.country ?? '',
    rank: attributes.rank ? `#${attributes.rank}` : '',
    lastWipe: formatDate(lastWipe, config.timezone),
    serverType: details.rust_type ?? ''
  };
}

export async function fetchNearestWipes(config) {
  let url = buildApiUrl(config).toString();
  const now = Date.now();
  const servers = [];

  for (let page = 0; page < config.battleMetrics.fetchPages && url; page += 1) {
    const payload = await fetchBattleMetricsPage(url);
    servers.push(...(payload.data ?? []));

    const filteredCount = servers
      .filter((server) => server.attributes?.details?.rust_next_wipe)
      .filter((server) => matchesServerType(server, config))
      .filter((server) => new Date(server.attributes.details.rust_next_wipe).getTime() >= now)
      .length;

    if (filteredCount >= config.battleMetrics.pageSize) {
      break;
    }

    url = payload.links?.next ?? '';
  }

  return servers
    .filter((server) => server.attributes?.details?.rust_next_wipe)
    .filter((server) => matchesServerType(server, config))
    .map((server) => toWipe(server, config))
    .filter((wipe) => new Date(wipe.timestamp).getTime() >= now)
    .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
    .slice(0, config.battleMetrics.pageSize);
}

export async function fetchAnnounceableWipes(config) {
  const wipes = await fetchNearestWipes(config);
  return wipes.filter((wipe) => isWithinAnnouncementWindow(wipe.timestamp, config));
}
