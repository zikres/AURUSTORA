import 'dotenv/config';

function required(name) {
  const value = process.env[name]?.trim();

  if (!value) {
    throw new Error(`Missing required environment variable: ${name}`);
  }

  return value;
}

function optional(name, fallback = '') {
  return process.env[name]?.trim() || fallback;
}

function serverTypes() {
  return optional('SERVER_TYPES', 'official,modded,community')
    .split(',')
    .map((type) => type.trim().toLowerCase())
    .filter(Boolean);
}

function channelIdForServerType(serverType) {
  if (serverType === 'modded') {
    return optional('MODDED_CHANNEL_ID') || optional('DISCORD_MODDED_CHANNEL_ID') || required('DISCORD_CHANNEL_ID');
  }

  if (serverType === 'community') {
    return optional('COMMUNITY_CHANNEL_ID') || optional('DISCORD_COMMUNITY_CHANNEL_ID') || required('DISCORD_CHANNEL_ID');
  }

  if (serverType === 'official') {
    return optional('OFFICIAL_CHANNEL_ID') || optional('DISCORD_OFFICIAL_CHANNEL_ID') || required('DISCORD_CHANNEL_ID');
  }

  return required('DISCORD_CHANNEL_ID');
}

function numberValue(name, fallback) {
  const raw = process.env[name]?.trim();
  if (!raw) {
    return fallback;
  }

  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive number`);
  }

  return parsed;
}

function optionalNumber(name) {
  const raw = process.env[name]?.trim();
  if (!raw) {
    return null;
  }

  const parsed = Number(raw);
  if (!Number.isFinite(parsed) || parsed < 0) {
    throw new Error(`${name} must be a non-negative number`);
  }

  return parsed;
}

export function loadConfig() {
  const types = serverTypes();
  const battleMetrics = {
    pageSize: Math.min(numberValue('BATTLEMETRICS_PAGE_SIZE', 10), 100),
    fetchPages: Math.min(numberValue('BATTLEMETRICS_FETCH_PAGES', 10), 25),
    minPlayers: optionalNumber('MIN_PLAYERS'),
    maxPlayers: optionalNumber('MAX_PLAYERS'),
    countries: optional('COUNTRIES'),
    announceWithinMinutes: optionalNumber('ANNOUNCE_WITHIN_MINUTES')
  };
  const baseConfig = {
    discordToken: required('DISCORD_TOKEN'),
    mentionRoleId: optional('MENTION_ROLE_ID'),
    wipeSourceUrl: required('WIPE_SOURCE_URL'),
    checkIntervalMinutes: numberValue('CHECK_INTERVAL_MINUTES', 10),
    timezone: optional('TIMEZONE', 'Europe/Moscow')
  };
  const targets = types.map((serverType) => ({
    ...baseConfig,
    channelId: channelIdForServerType(serverType),
    battleMetrics: {
      ...battleMetrics,
      serverType
    }
  }));

  return {
    ...baseConfig,
    targets
  };
}
