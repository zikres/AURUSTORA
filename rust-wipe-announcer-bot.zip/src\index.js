import { Client, EmbedBuilder, GatewayIntentBits } from 'discord.js';
import { loadConfig } from './config.js';
import { fetchAnnounceableWipes, fetchNearestWipes } from './scraper.js';
import { loadState, saveState } from './state.js';

const checkOnce = process.argv.includes('--check-once');

function formatNow(timezone) {
  return new Intl.DateTimeFormat('ru-RU', {
    dateStyle: 'short',
    timeStyle: 'medium',
    timeZone: timezone
  }).format(new Date());
}

function getChannel(client, config) {
  return client.channels.fetch(config.channelId).then((channel) => {
    if (!channel?.isTextBased()) {
      throw new Error(`Channel ${config.channelId} is not a text channel or is unavailable`);
    }

    return channel;
  });
}

function createWipeEmbed(wipe, config) {
  const embed = new EmbedBuilder()
    .setColor(0xb7410e)
    .setTitle(wipe.title)
    .setDescription(wipe.date ? `Next wipe: **${wipe.date}**` : 'New Rust wipe found.')
    .setFooter({ text: `Checked: ${formatNow(config.timezone)}` })
    .setTimestamp(new Date());

  if (wipe.link) {
    embed.setURL(wipe.link);
  }

  const fields = [
    wipe.players ? { name: 'Players', value: wipe.players, inline: true } : null,
    wipe.rank ? { name: 'Rank', value: wipe.rank, inline: true } : null,
    wipe.country ? { name: 'Country', value: wipe.country, inline: true } : null,
    wipe.serverType ? { name: 'Type', value: wipe.serverType, inline: true } : null,
    wipe.address ? { name: 'Address', value: wipe.address, inline: true } : null,
    wipe.lastWipe ? { name: 'Last wipe', value: wipe.lastWipe, inline: true } : null
  ].filter(Boolean);

  if (fields.length > 0) {
    embed.addFields(fields);
  }

  return embed;
}

function createNearestSummaryEmbed(wipes, config) {
  const lines = wipes.slice(0, 10).map((wipe, index) => {
    const parts = [
      `**${index + 1}. [${wipe.title}](${wipe.link})**`,
      `Next wipe: ${wipe.date}`,
      `Players: ${wipe.players}`,
      wipe.serverType ? `Type: ${wipe.serverType}` : '',
      wipe.rank ? `Rank: ${wipe.rank}` : '',
      wipe.country ? `Country: ${wipe.country}` : ''
    ].filter(Boolean);

    return parts.join('\n');
  });

  return new EmbedBuilder()
    .setColor(0xb7410e)
    .setTitle('Closest Rust wipes')
    .setDescription(lines.length > 0 ? lines.join('\n\n') : 'No upcoming wipes found in the checked BattleMetrics list.')
    .setFooter({ text: `BattleMetrics checked: ${formatNow(config.timezone)}` })
    .setTimestamp(new Date());
}

function summarySignature(wipes) {
  const ids = wipes
    .slice(0, 10)
    .map((wipe) => wipe.id)
    .join('|');

  return ids;
}

function typedSignature(config, signature) {
  return `${config.battleMetrics.serverType}:${signature}`;
}

function targetKey(config) {
  return `${config.battleMetrics.serverType}:${config.channelId}`;
}

function seenKey(config, wipe) {
  return `${targetKey(config)}:${wipe.id}`;
}

async function sendNearestSummary(client, config, state, force = false) {
  const wipes = await fetchNearestWipes(config);
  const signature = typedSignature(config, summarySignature(wipes));
  const summaryKey = targetKey(config);
  const lastSummarySignature = state.lastSummarySignatures?.[summaryKey] ?? state.lastSummarySignature;

  if (!force && signature && signature === lastSummarySignature) {
    console.log(`[${formatNow(config.timezone)}] ${config.battleMetrics.serverType}: closest wipes list has not changed.`);
    return;
  }

  const channel = await getChannel(client, config);
  await channel.send({ embeds: [createNearestSummaryEmbed(wipes, config)] });

  state.lastSummarySignatures ??= {};
  state.lastSummarySignatures[summaryKey] = signature;
  await saveState(state);
  console.log(`[${formatNow(config.timezone)}] ${config.battleMetrics.serverType}: posted closest wipes summary (${wipes.length} wipes).`);
}

async function sendNewWipeAlerts(client, config, state) {
  const wipes = await fetchAnnounceableWipes(config);
  const newWipes = wipes.filter((wipe) => !state.seen.has(seenKey(config, wipe)));

  if (newWipes.length === 0) {
    console.log(`[${formatNow(config.timezone)}] ${config.battleMetrics.serverType}: no new wipe alerts.`);
    return;
  }

  const channel = await getChannel(client, config);

  for (const wipe of newWipes) {
    const content = config.mentionRoleId ? `<@&${config.mentionRoleId}>` : undefined;

    await channel.send({
      content,
      embeds: [createWipeEmbed(wipe, config)],
      allowedMentions: config.mentionRoleId ? { roles: [config.mentionRoleId] } : { parse: [] }
    });

    state.seen.add(seenKey(config, wipe));
    console.log(`[${formatNow(config.timezone)}] ${config.battleMetrics.serverType}: posted wipe alert: ${wipe.title}`);
  }

  await saveState(state);
}

async function checkBattleMetrics(client, config, state, forceSummary = false) {
  for (const target of config.targets) {
    await sendNearestSummary(client, target, state, forceSummary);
    await sendNewWipeAlerts(client, target, state);
  }
}

async function main() {
  const config = loadConfig();
  const state = await loadState();
  const client = new Client({ intents: [GatewayIntentBits.Guilds] });

  client.once('clientReady', async () => {
    console.log(`Logged in as ${client.user.tag}`);

    try {
      await checkBattleMetrics(client, config, state, checkOnce);
    } catch (error) {
      console.error(error);
    }

    if (checkOnce) {
      await client.destroy();
      return;
    }

    const intervalMs = config.checkIntervalMinutes * 60 * 1000;
    setInterval(async () => {
      try {
        await checkBattleMetrics(client, config, state);
      } catch (error) {
        console.error(error);
      }
    }, intervalMs);
  });

  await client.login(config.discordToken);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
