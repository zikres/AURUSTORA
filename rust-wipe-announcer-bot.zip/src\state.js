import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const statePath = path.resolve('data', 'bot-state.json');

export async function loadState() {
  try {
    const raw = await readFile(statePath, 'utf8');
    const parsed = JSON.parse(raw);

    return {
      seen: new Set(Array.isArray(parsed.seen) ? parsed.seen : []),
      lastSummarySignatures: parsed.lastSummarySignatures ?? {},
      lastSummarySignature: parsed.lastSummarySignature ?? ''
    };
  } catch (error) {
    if (error.code === 'ENOENT') {
      return {
        seen: new Set(),
        lastSummarySignatures: {},
        lastSummarySignature: ''
      };
    }

    throw error;
  }
}

export async function saveState(state) {
  await mkdir(path.dirname(statePath), { recursive: true });

  const payload = {
    seen: [...state.seen],
    lastSummarySignatures: state.lastSummarySignatures ?? {},
    lastSummarySignature: state.lastSummarySignature ?? '',
    updatedAt: new Date().toISOString()
  };

  await writeFile(statePath, `${JSON.stringify(payload, null, 2)}\n`, 'utf8');
}
